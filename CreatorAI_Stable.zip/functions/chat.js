// CreatorAI v8 — Multimodal backend with vision + text routing

const https = require("https");

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

// ── HTTP util ──────────────────────────────────────────────────
function post(hostname, path, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = https.request(
      { hostname, path, method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload), ...headers } },
      (res) => {
        let raw = "";
        res.on("data", c => raw += c);
        res.on("end", () => {
          try { resolve({ ok: res.statusCode < 300, status: res.statusCode, data: JSON.parse(raw) }); }
          catch(e) { resolve({ ok: false, status: res.statusCode, data: null, raw }); }
        });
      }
    );
    req.on("error", reject);
    req.write(payload);
    req.end();
  });
}

function getText(res) {
  return res?.data?.choices?.[0]?.message?.content?.trim() || null;
}

// ── Groq text call ─────────────────────────────────────────────
function groqText(apiKey, system, messagesOrString, maxTokens, temp) {
  const messages = [{ role: "system", content: system }];
  if (Array.isArray(messagesOrString)) messages.push(...messagesOrString);
  else messages.push({ role: "user", content: messagesOrString });
  // Add timeout wrapper — Netlify free tier has 10s limit
  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error("Groq API timeout after 8s")), 8000)
  );
  const apiCall = post(
    "api.groq.com", "/openai/v1/chat/completions",
    { model: "llama-3.3-70b-versatile", messages, max_tokens: maxTokens, temperature: temp },
    { "Authorization": "Bearer " + apiKey }
  );
  return Promise.race([apiCall, timeoutPromise]);
}

// ── Groq vision call ───────────────────────────────────────────
// Uses Llama 4 Scout which supports image input on Groq
function groqVision(apiKey, systemPrompt, userText, imageBase64, mimeType) {
  const messages = [
    { role: "system", content: systemPrompt },
    {
      role: "user",
      content: [
        {
          type: "image_url",
          image_url: { url: "data:" + mimeType + ";base64," + imageBase64 }
        },
        { type: "text", text: userText || "Analyze this image and give creator-focused insights." }
      ]
    }
  ];
  return post(
    "api.groq.com", "/openai/v1/chat/completions",
    { model: "meta-llama/llama-4-scout-17b-16e-instruct", messages, max_tokens: 1000, temperature: 0.7 },
    { "Authorization": "Bearer " + apiKey }
  );
}

// ══════════════════════════════════════════════════════════════
// MASTER IDENTITY
// ══════════════════════════════════════════════════════════════

const MASTER_IDENTITY = `You are CreatorAI — an advanced AI assistant built for content creators.

IDENTITY: Your name is CreatorAI. If asked: "My name is CreatorAI."
Never say you are made by Meta, Google, Anthropic, or any AI company.

PURPOSE: Help creators with viral hooks, scripts, storytelling, ideas, captions, hashtags, thumbnails, and multi-platform content.

BANNED PHRASES: "what if I told you", "little did I know", "everything changed", "in that moment", "journey", "unlock the secret", "game-changer", "I completely understand", "Here are X tips", "you've got this"

SELF-CHECK before responding:
- Is this repetitive? → rewrite
- Is this too generic? → make it specific  
- Does this sound human? → rewrite if robotic
- Did I follow constraints exactly? → fix if not

TONE: Creator friend, not corporate bot. Modern, practical, direct.`;

const VISION_IDENTITY = `You are CreatorAI — an AI visual analyst for content creators.

Your job: analyze uploaded images and give PRACTICAL creator insights.
Think like a content strategist, not a generic image describer.

WHEN ANALYZING IMAGES:
- Thumbnails → critique composition, text, emotion, curiosity gap, CTR potential
- Screenshots of posts → analyze hooks, captions, engagement signals
- Artwork/graphics → suggest content angles, story ideas, mood-based scripts
- Creator content → analyze style, format, audience targeting
- Competitor content → identify strategy, format patterns, gaps to exploit

BE SPECIFIC: Don't say "the image shows a person." Say what it means for the creator's content.
BE ACTIONABLE: End every analysis with 2-3 concrete next steps.
AVOID: Generic descriptions. Robotic responses. "I cannot identify faces."

Your name is CreatorAI. Never mention Llama, Meta, or any AI company.`;

// ══════════════════════════════════════════════════════════════
// KEYWORD CLASSIFIER
// ══════════════════════════════════════════════════════════════

const PERSONAL_EMOTIONAL = [
  "i'm scared", "im scared", "i am scared", "i'm afraid",
  "i feel like giving up", "i want to quit",
  "what if i fail", "what if i don't make it",
  "i have imposter syndrome", "i doubt myself",
  "i'm demotivated", "i'm anxious about my channel",
  "i feel hopeless", "i'm not good enough"
];

const CONTENT_TONE = [
  "make it sad", "make it dark", "make it scary", "make it emotional",
  "write a sad", "write a dark", "write a horror", "horror style",
  "dark psychology", "make it intense", "cinematic"
];

const GREETING = ["hi", "hello", "hey", "hii", "what's up", "wassup", "yo", "sup"];
const SEARCH   = ["who is", "what is", "trending", "latest", "news", "update", "price of", "how much", "stats", "subscribers", "msa", "mrbeast", "pewdiepie", "best tool for", "which tool"];
const IDEAS    = ["give me ideas", "video ideas", "content ideas", "what to post", "suggest topics", "ideas for my"];
const SCRIPT   = ["write a script", "write me a script", "script for", "video script", "style script", "write a story", "story about", "script about", "dramatic script", "narration", "faceless script"];
const HASHTAGS = ["hashtags", "best tags", "tags for", "captions for"];
const HOOK     = ["write a hook", "give me hooks", "hook for", "viral hook", "opening line", "best hook"];
const PACKAGE  = ["full package", "complete package", "title and script", "everything for", "full video idea", "content package"];

function keywordClassify(msg) {
  const m = msg.toLowerCase();
  const words = m.trim().split(/\s+/);
  if (words.length <= 5 && GREETING.some(w => m.startsWith(w))) return "greeting";
  if (CONTENT_TONE.some(w => m.includes(w))) return "script";
  if (PERSONAL_EMOTIONAL.some(w => m.includes(w))) return "emotional";
  if (SEARCH.some(w => m.includes(w))) return "search";
  if (PACKAGE.some(w => m.includes(w))) return "package";
  if (HOOK.some(w => m.includes(w))) return "hook";
  if (SCRIPT.some(w => m.includes(w))) return "script";
  if (IDEAS.some(w => m.includes(w))) return "content_ideas";
  if (HASHTAGS.some(w => m.includes(w))) return "hashtags";
  return null;
}

const AI_CLASSIFIER = `Classify this creator chat message. Reply with ONE label only, nothing else.
Labels: greeting | emotional | search | content_ideas | hook | script | hashtags | package | creator_advice | unclear
"make it sad/dark/cinematic" → script (tone request, not personal emotion)
"I'm scared/failing" → emotional
"who is [person]" → search
"full package" → package
"best hook" → hook`;

async function classifyWithAI(message, groqKey) {
  try {
    const res = await groqText(groqKey, AI_CLASSIFIER, message, 20, 0);
    const raw = getText(res) || "unclear";
    const valid = ["greeting","emotional","search","content_ideas","hook","script","hashtags","package","creator_advice","unclear"];
    const label = raw.toLowerCase().replace(/[^a-z_]/g,"").trim();
    const matched = valid.find(v => label.startsWith(v));
    console.log(`[AI_CLASSIFY] raw="${raw}" matched="${matched||"unclear"}"`);
    return matched || "unclear";
  } catch(e) {
    console.error("[AI_CLASSIFY] failed:", e.message, "— defaulting to creator_advice");
    return "creator_advice"; // safe fallback
  }
}

async function classify(message, groqKey) {
  const kw = keywordClassify(message);
  if (kw) { console.log(`[CLASSIFY] keyword→${kw}`); return kw; }
  const ai = await classifyWithAI(message, groqKey);
  console.log(`[CLASSIFY] AI→${ai}`);
  return ai;
}

// ══════════════════════════════════════════════════════════════
// SEARCH (Tavily)
// ══════════════════════════════════════════════════════════════

async function tavilySearch(query, key) {
  try {
    const res = await post("api.tavily.com", "/search",
      { api_key: key, query, search_depth: "basic", max_results: 3, include_answer: true });
    return res.ok ? res.data : null;
  } catch(e) { return null; }
}

function buildSearchContext(data) {
  if (!data) return null;
  let ctx = data.answer ? `Answer: ${data.answer}\n\n` : "";
  (data.results||[]).slice(0,3).forEach((r,i) => {
    ctx += `[${i+1}] ${r.title}: ${(r.content||"").substring(0,200)}\n`;
  });
  return ctx.trim() || null;
}

// ══════════════════════════════════════════════════════════════
// RESPONSE GENERATORS
// ══════════════════════════════════════════════════════════════

const GREETINGS = [
  "Hey 👋 What are you creating today?",
  "Hi! Scripts, hooks, ideas, hashtags — what do you need?",
  "Hey! What are we building today? 🎬",
  "What's up! What kind of content are we making?"
];
function handleGreeting() { return GREETINGS[Math.floor(Math.random()*GREETINGS.length)]; }

async function handleEmotional(msg, key) {
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nUser is expressing personal anxiety about their creator journey.\nWrite EXACTLY 2 sentences. Sentence 1: casual acknowledgment. Sentence 2: one grounded practical insight.\nNo lists. No bold. No motivation speech. Sound like a friend.`,
    msg, 80, 0.7);
  return getText(res) || "That fear is pretty normal at the start. Focus on improving one thing per video instead of worrying about the results.";
}

async function handleUnclear(msg, key) {
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nMessage is unclear. Ask ONE short clarifying question. One sentence. Casual.`,
    msg, 40, 0.7);
  return getText(res) || "What do you need — ideas, a script, hooks, or something else?";
}

async function handleSearch(msg, key, tavilyKey) {
  if (!tavilyKey) return "I don't have live search available — I'd rather say that than guess wrong.";
  const data = await tavilySearch(msg, tavilyKey);
  const ctx = buildSearchContext(data);
  if (!ctx) return "I searched but found nothing reliable. Check directly — I don't want to make something up.";
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nAnswer using ONLY these search results. Do NOT add from your own knowledge. Under 150 words. Start with "🔍 [Search Used]".\n\nRESULTS:\n${ctx}`,
    msg, 250, 0.2);
  return getText(res) || "Search results were unclear. Check directly for accurate info.";
}

async function handleIdeas(msg, history, key, niche, platform) {
  const msgs = history.slice(-4).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nGenerate exactly 5 content ideas for a ${platform} creator in the ${niche} niche.\nFormat: 1. **[Title]** — one sentence why it works. No intro. Start with "1."`,
    msgs.length ? msgs : msg, 400, 0.92);
  return getText(res) || "What's your niche? I'll generate specific ideas for it.";
}

async function handleHook(msg, history, key, niche, platform) {
  const msgs = history.slice(-4).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nWrite 5 viral hooks for ${platform} in ${niche} niche.\nEach must create: curiosity, tension, surprise, or urgency.\nForbidden: "Have you ever wondered...", "Today I'm going to show you...", "In this video..."\nFormat: 1. [hook] — [why it works in 5 words]. No intro.`,
    msgs.length ? msgs : msg, 400, 0.93);
  return getText(res) || "What topic or niche is this hook for?";
}

async function handleScript(msg, history, key, niche, platform) {
  const msgs = history.slice(-6).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nYou are a world-class scriptwriter for ${platform} in ${niche} niche.\nWrite the actual script. Not advice. The script itself.\nStart immediately — no intro sentences. Follow user's exact style, character, setting.\nStory format: [SCENE] → Hook → Conflict → Escalation → Payoff → Ending\nStandard format: 🎣 HOOK | 📖 CONTENT | 📣 CTA\nBanned: "little did she know", "everything changed", "in that moment"`,
    msgs.length ? msgs : msg, 1000, 0.93);
  return getText(res) || "What's the topic, style, and platform for this script?";
}

async function handleHashtags(msg, history, key, niche, platform) {
  const msgs = history.slice(-4).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nGenerate 25 unique hashtags for ${niche} on ${platform}.\n🔥 HIGH VOLUME (5 — 1M+ posts)\n⚡ MEDIUM (10 — 100K–1M)\n🎯 NICHE (10 — under 100K)\nEnd with one tactical tip. No intro. Start with 🔥`,
    msgs.length ? msgs : msg, 350, 0.8);
  return getText(res) || "What's the topic for these hashtags?";
}

async function handlePackage(msg, history, key, niche, platform) {
  const msgs = history.slice(-4).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nGenerate a complete content package for ${platform} in ${niche}.\n📌 TITLE\n🎣 HOOK\n📝 SCRIPT OUTLINE\n🖼️ THUMBNAIL TEXT (max 5 words)\n📣 CTA\n#️⃣ HASHTAGS (10 best)\n📱 CAPTION\nMake everything specific. No generic filler.`,
    msgs.length ? msgs : msg, 700, 0.9);
  return getText(res) || "What's the topic, niche, and platform for this package?";
}

async function handleAdvice(msg, history, key, niche, platform) {
  const msgs = history.slice(-6).map(m => ({ role: m.role==="assistant"?"assistant":"user", content: String(m.content) }));
  const res = await groqText(key,
    `${MASTER_IDENTITY}\nYou are a creator strategist for ${platform} in ${niche}.\nPractical advice. Max 120 words. Bullets where useful. Vary structure. No filler.`,
    msgs.length ? msgs : [{ role:"user", content:msg }], 250, 0.78);
  return getText(res) || "Can you tell me more about what you're working on?";
}

// ══════════════════════════════════════════════════════════════
// VISION HANDLER — real image analysis
// ══════════════════════════════════════════════════════════════

async function handleVision(userText, imageBase64, mimeType, mode, niche, platform, key) {
  console.log(`[VISION] Analyzing image — mime:${mimeType} mode:${mode}`);

  const contextPrompt = `${VISION_IDENTITY}

Creator context:
- Niche: ${niche}
- Platform: ${platform}
- Active mode: ${mode}

User's request: "${userText || "Analyze this image and give me creator insights."}"

Analyze this image as a content strategist. Give practical, specific insights.
End with 2-3 concrete next steps the creator should take.`;

  try {
    const res = await groqVision(key, contextPrompt, userText, imageBase64, mimeType);
    const text = getText(res);
    if (text) {
      console.log("[VISION] Success, response length:", text.length);
      return text;
    }
    console.log("[VISION] Empty response from vision model:", JSON.stringify(res?.data).substring(0,200));
    return "I can see you uploaded an image. My vision analysis is temporarily unavailable — try describing what's in the image and I'll give you creator insights based on that.";
  } catch(e) {
    console.error("[VISION] Error:", e.message);
    return "Image analysis hit an error: " + e.message + ". Try describing the image in text and I'll help from there.";
  }
}

// ══════════════════════════════════════════════════════════════
// MAIN HANDLER
// ══════════════════════════════════════════════════════════════

exports.handler = async function(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: CORS, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 200, headers: CORS, body: JSON.stringify({ text: "Wrong method" }) };

  try {
    const groqKey   = (process.env.GROQ_API_KEY   || "").trim();
    const tavilyKey = (process.env.TAVILY_API_KEY  || "").trim();

    console.log(`[BOOT] GROQ:${!!groqKey} TAVILY:${!!tavilyKey}`);

    if (!groqKey) return { statusCode: 200, headers: CORS,
      body: JSON.stringify({ text: "❌ GROQ_API_KEY missing in Netlify environment variables." }) };

    const body     = JSON.parse(event.body || "{}");
    const niche    = body.niche      || "General Content Creation";
    const platform = body.platform   || "YouTube";
    const mode     = body.mode       || "ideas";
    const messages = body.messages   || [];
    const image    = body.image      || null; // { base64, mimeType }

    const lastUser = [...messages].reverse().find(m => m.role === "user");
    const userText = lastUser ? String(lastUser.content).trim() : "";

    if (!userText && !image) return { statusCode: 200, headers: CORS,
      body: JSON.stringify({ text: "What do you need help with?" }) };

    console.log(`[MSG] "${userText.substring(0,80)}" | image:${!!image}`);

    // ── VISION ROUTE — takes priority when image is attached ──
    if (image && image.base64 && image.mimeType) {
      const text = await handleVision(userText, image.base64, image.mimeType, mode, niche, platform, groqKey);
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ text, intent: "vision" }) };
    }

    // ── TEXT ROUTE ─────────────────────────────────────────────
    const intent = await classify(userText, groqKey);
    console.log(`[ROUTE] → ${intent}`);

    let text = "";
    switch(intent) {
      case "greeting":      text = handleGreeting(); break;
      case "emotional":     text = await handleEmotional(userText, groqKey); break;
      case "unclear":       text = await handleUnclear(userText, groqKey); break;
      case "search":        text = await handleSearch(userText, groqKey, tavilyKey); break;
      case "content_ideas": text = await handleIdeas(userText, messages, groqKey, niche, platform); break;
      case "hook":          text = await handleHook(userText, messages, groqKey, niche, platform); break;
      case "script":        text = await handleScript(userText, messages, groqKey, niche, platform); break;
      case "hashtags":      text = await handleHashtags(userText, messages, groqKey, niche, platform); break;
      case "package":       text = await handlePackage(userText, messages, groqKey, niche, platform); break;
      default:              text = await handleAdvice(userText, messages, groqKey, niche, platform); break;
    }

    console.log(`[DONE] intent:${intent} len:${text.length}`);
    return { statusCode: 200, headers: CORS, body: JSON.stringify({ text, intent }) };

  } catch(e) {
    console.error("[ERROR]", e.message);
    return { statusCode: 200, headers: CORS, body: JSON.stringify({ text: "Server error: " + e.message }) };
  }
};
